﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Xml;
using System.Threading.Tasks;
using System.IO;


/*
 * Author: Shyam Joshi <shyam1joshi@gmail.com> 
 * 
 */
namespace ConsoleApplication2
{
    class WebRequestKPI
    {

        public static String UserNameString = "email";
        public static String PasswordString = "password";


        public HttpWebRequest request;
        public String username;
        public String password;

        public void setConfigFile() { 

        }

        public void getConfigFile() { 
        }
        public void processConfigFile() {


            XmlDocument doc = new XmlDocument();
            doc.Load("config.xml");

            XmlNode usernode = doc.DocumentElement.SelectSingleNode("/credentials/username");
            XmlNode passnode = doc.DocumentElement.SelectSingleNode("/credentials/password");

            username = usernode.InnerText;
            password = passnode.InnerText;
        }

        public void connectWithCredentials() { 
        }

        //public String getInfowithURL(String url, Dictionary<String, String> postDataInfo)
        //{

        //    request = (HttpWebRequest)WebRequest.Create(url);
        //    var postData = "";//String.Format("email={0}&password={1}", username, password);
        //    int max = postDataInfo.Count;
        //    for (int cnt = 0; cnt < max; cnt++)
        //    {
        //        if (cnt != 0 && cnt < max) postData = postData + "&";
        //        KeyValuePair<String, String> onepostData = postDataInfo.ElementAt(cnt);
        //        postData = postData + String.Format("{0}={1}", onepostData.Key, onepostData.Value);
        //    }


        //    var data = Encoding.ASCII.GetBytes(postData);
        //    Console.WriteLine(postData);
        //    request.Method = "POST";
        //    request.ContentType = "application/x-www-form-urlencoded";
        //    request.ContentLength = data.Length;

        //    using (var stream = request.GetRequestStream())
        //    {
        //        stream.Write(data, 0, data.Length);
        //    }

        //    var response = (HttpWebResponse)request.GetResponse();

        //    var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();


        //    Console.WriteLine(responseString);


        //    return responseString;
        //}

        public String getInfowithURLxml(String url, Dictionary<String, XmlDocument> postDataInfo)
        {

            request = (HttpWebRequest)WebRequest.Create(url);
            var postData = "";//String.Format("email={0}&password={1}", username, password);
            int max = postDataInfo.Count;
            for (int cnt = 0; cnt < max; cnt++)
            {
                if (cnt != 0 && cnt < max) postData = postData + "&";
                KeyValuePair<String, XmlDocument> onepostData = postDataInfo.ElementAt(cnt);
                postData = postData + String.Format("{0}={1}", onepostData.Key, onepostData.Value);
            }

            byte[] bytes = Encoding.UTF8.GetBytes(postData.ToString());

            request.ContentLength = bytes.Length;
            Console.WriteLine(bytes);
            request.Method = "POST";
            //request.ContentType = "application/xml";
            //request.Accept = "application/xml";
            request.ContentType = " multipart/form-data";
            
            
          

            using (var stream = request.GetRequestStream())
            {
                stream.Write(bytes, 0, bytes.Length);
            }

            var response = (HttpWebResponse)request.GetResponse();

            var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

            Console.WriteLine(responseString);

            return responseString;
        }

    }




}
