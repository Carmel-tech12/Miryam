﻿using System;

using System.Collections.Generic;

using System.Linq;

using System.Text;

using System.Net;

using System.Threading.Tasks;

using System.IO;

using System.Xml;
using System.Collections.Specialized;




/*

 * Author: Shyam Joshi <shyam1joshi@gmail.com> 

 * 

 */

namespace ConsoleApplication2
{

    class Program
    {

        static void Main(string[] args)
        {



            Console.WriteLine("webrequest");



            HttpWebRequest httpRequest = (HttpWebRequest)WebRequest.Create("https://kpi-procbp.dira2.co.il//products//importxml");

            NameValueCollection nvc = new NameValueCollection();
            //nvc.Add("id", "TTR");
            nvc.Add("email", "EMAIL_HERE");
            nvc.Add("password", "PASSWORD_HERE");
          String info =   Post_File.HttpUploadFile("https://kpi-procbp.dira2.co.il//products//importxml", @"C:\\miryam\\KPI\\test1.xml", "uploadfile", "application/xml", nvc);

          Console.Write(info);
          Console.Read();
        }

    }

}