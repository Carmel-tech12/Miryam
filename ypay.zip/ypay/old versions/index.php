<?php 
 error_reporting(E_ALL);
/**********includes payproces *************/
 include('app/payprocess.php');
 
include('app/heshinprocess.php');
include('app/moveininvoice.php');
include('app/moveinreceipts.php');

/*
 * 
 * imoveinforinvoice Test
 * 
 * 
 * 
 */

 $object = new Moveininvoice();
 
  $object->CardTransactions = 88888888;
 $object->VATTicketDeals = 88888888;
 $object->CashFundCard = 88888888;
 $object->CardCreditFund = 88888888;
 
 
$str = $object->moveininvoicewithDateandtime("2016-09-25 03:10:00", "2016-12-20 03:10:00", null,null,true);


if (is_resource($str)) {
        rewind($str);
     echo    stream_get_contents($str);
}

echo $object->error;
 
 /*
 * 
 * Heshin Test
 * 
 * 
 * 
 */


$object = new Heshinprocess();
 
  $object->CardTransactions = 88888888;
 $object->VATTicketDeals = 88888888;
 $object->CashFundCard = 88888888;
 $object->CardCreditFund = 88888888;
 
 
$str = $object->heshinwithDateandtime("2016-09-25 03:10:00", "2016-12-20 03:10:00", null,null,true);


if (is_resource($str)) {
        rewind($str);
     echo    stream_get_contents($str);
}

echo $object->error;
 




$object = new Heshinprocess();
 
  $object->CardTransactions = 88888888;
 $object->VATTicketDeals = 88888888;
 $object->CashFundCard = 88888888;
 $object->CardCreditFund = 88888888;
 
 
$str = $object->heshinwithDateandtime("2016-09-25 03:10:00", "2016-12-20 03:10:00", null,null,true);


if (is_resource($str)) {
        rewind($str);
     echo    stream_get_contents($str);
}

echo $object->error;
 

?>
