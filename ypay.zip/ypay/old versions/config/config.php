<?php 

/*
 * $outputcfg list of outpput parameters
 * $outputcfg['dbhost'] = db host 
 * $outputcfg['dbname'] = database name
 * $outputcfg['dbusername']  = database username
 * $outputcfg['dbpassword']  = database password
 * 
 */
$dbconfig = array( 'dbhost' => 'localhost',
		   'dbname' => 'ypay',
	           'dbusername' => 'ypay',
	 	   'dbpassword' => 'ypay'		   		
		);
/*
 * $outputcfg list of output parameters
 * default values
 * $outputcfg['outputpath'] = 'output/'
 * $outputcfg['hesinfilename'] = 'heshin.dat'
 * $outputcfg['invoicemoveinfilename']  = 'moveininvoice.dat'
 * $outputcfg['receiptmoveinfilename']  = 'moveinreceipt.dat'
 * 
 */

$logon = true; // set this to false to generate Logs 

$outputcfg = array(
                   "download"=>true,
		   'outputpath' => 'output/',	
		   'hesinfilename' => 'heshin.dat',
		   'invoicemoveinfilename' => 'moveininvoice.doc',
		   'receiptmoveinfilename' => 'moveinreceipt.doc',	
		);

?>
