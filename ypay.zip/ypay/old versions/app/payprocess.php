<?php 

    /***********************Global variables*******************************/
	$path='output/';
        $configpath = 'config/config.php';        
        include('lib/log4php/src/main/php/Logger.php');
        include "models.php";
        Logger::configure('lib/log4php/config.xml');
   /**************************************************************/

  class Payprocess{
      
      
        public $error_array = array(
            "account_key_missing"=>"בכל תנועה חייב להיות לפחות מפתח חשבון חובה או מפתח חשבון זכות.",
            "fee_missing"=>"אי אפשר להעביר תנועות ללא סכום.",
            "total_missing"=>"בכל תנועה חייב להיות לפחות סכום אחד.",
            "funds_account_mismatch"=>"לכל סכום שמועבר חייב להיות חשבון בהתאמה, אבל אפשר להעביר חשבונות ללא סכומים (חשבונות אינפורמטיביים).",
            "total_duty_total_right_mismatch"=>"כאשר בתנועה יש גם סכום בחובה וגם סכום בזכות התנועה חייבת להיות מאוזנת (סך חובה = סך זכות). תנועה מאוזנת היא תנועה שסך הסכומים בחובה שווה לסך הסכומים בזכות.",
            "dates_not_valid"=>"תאריכי הערך והאסמכתא חייבים להיות בגבולות התאריכים שהמשתמש הגדיר בסעיף הגדרות חברה בתפריט הגדרות.",
            "label_only_movement"=>"סוג התנועה משמש כסימון בלבד ואינו קובע את פיצול התנועה."
        );

	private $query;
        private $root;
        private $log;
        public $CardTransactions,$VATTicketDeals,$CashFundCard,$CardCreditFund;
        
        public function __construct()
        {
            // The __CLASS__ constant holds the class name
            $this->log = Logger::getLogger(__CLASS__);
        }
        /*
         *  connect to the database
         */
	public function connect(){
          $log = $this->log;
	  include($GLOBALS['configpath']);	
          if(!$logon)
          {
              $log = null;
          }
          
	  if(isset($dbconfig['dbusername']) && !empty($dbconfig['dbusername']))
	  {
	  	$user = $dbconfig['dbusername']; 
	  }
          else 
	  {
               echo "Database username is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database username is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbpassword']) && !empty($dbconfig['dbpassword']))
	  {
	  	$pass = $dbconfig['dbpassword'];
	  }
          else 
	  {
               echo "Database password is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database password is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbname']) && !empty($dbconfig['dbname']))
	  {
	  	$dbname = $dbconfig['dbname'];
	  }
          else 
	  {
               echo "Database name is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database name is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbhost']) && !empty($dbconfig['dbhost']))
	  {
	  	$dbhost = $dbconfig['dbhost'];
	  }
          else 
	  {
               echo "Database host is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database host is not set. Please check the config."); 
               die();
	  }
          try{
		  $dbh = new PDO('mysql:host='.$dbhost.';dbname='.$dbname, $user, $pass);
                  if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : database connection created ");
		  return $dbh;
          }catch(Exception $ex)
	  {
                 echo "Exception thrown :";
                 echo $ex->getMessage();
                if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Exception thrown : ".$ex->getMessage()); 
		die();
	  }
       	}
         /*
         *  generate movein for receipt
         */
	public function generateMoveinReceipt(){
		
          try{
                $log = $this->log;
                
                if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : file generation for movein for receipts started ");
                
		include($GLOBALS['configpath']);	

		 if(isset($outputcfg['outputpath']) && !empty($outputcfg['outputpath']))
		 	$this->root =$outputcfg['outputpath'];
		 else
		 	$this->root =$GLOBALS['path'];

                 if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : output location : ".$this->root);
                 
		 if(!is_dir($this->root))
			mkdir($this->root, 0777,true);
	    
		 if(isset($outputcfg['receiptmoveinfilename']) && !empty($outputcfg['receiptmoveinfilename']))
		 	$file = $outputcfg['receiptmoveinfilename'];
		 else
		 	$file = 'moveinreceipt.dat';
                                  
                 if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : movein for receipt filename : ".$file);

		 $filepath = $this->root.$file;
		    
		 if(file_exists($filepath))
		 {
			unlink($filepath);  
			$fp = fopen($filepath, "w");            
		 }
		 else 
		 {
			$fp = fopen($filepath, "w");
		 }
		try{
                    
                    $con = $this->connect();
                    $this->query = "select d.*, p.payment_id, p.type as ptype from document as d inner join payment_method as p on d.id = p.payment_id ";

                    $con->query("SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', 					character_set_database = 'utf8', character_set_server = 'utf8'"); 
                    $result = $con->query($this->query);
                    
               	}catch(PDOException  $e ){
			echo "Error: ".$e;
                        if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Error: ".$e);
			die();
		}  
		$str="";
		if($result)
		{
			foreach($result as $res)
			{ 
				if($res['type'] == 'income')
				{
					if($res['document_type'] == 'receipt' || $res['document_type'] == 'invoice_receipt')
					{
						
                                            if(!empty($res['serial_number']))
                                            {
                                                $str .= str_pad(" ",8," ",STR_PAD_LEFT);

                                                $str .= str_pad($res['serial_number'],9," ",STR_PAD_LEFT);

                                                $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                if(!empty($res['created_at']))
                                                    $str .= str_pad(substr(strftime("%d/%m/%y",strtotime($res['created_at'])),0,10),10," ",STR_PAD_LEFT);
                                                else{
                                                        $str .= str_pad(substr(strftime("%d/%m/%y",strtotime($res['created_at'])),0,10),10," ",STR_PAD_LEFT);
                                                        if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : created_at is empty for record number ".$res['id']);
                                                }
                                                $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                if(!empty($res['produced_at']))
                                                    $str .= str_pad(substr(strftime("%d/%m/%y",strtotime($res['produced_at'])),0,10),10," ",STR_PAD_LEFT);
                                                else{
                                                        $str .= str_pad(substr(strftime("%d/%m/%y",strtotime($res['produced_at'])),0,10),10," ",STR_PAD_LEFT);
                                                        if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : produced_at is empty for record number ".$res['id']);
                                                }
                                                $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                if(!empty($res['details']))
                                                {
                                                        $tempbefore = iconv('UTF-8','Windows-1255//TRANSLIT',$res['details']);
                                                        $temp = strrev($tempbefore);
                                                        $str .= str_pad(substr($temp,0,20),20," ",STR_PAD_LEFT);
                                                 }else{
                                                          $str .= str_pad(" ",20," ",STR_PAD_LEFT);
                                                        if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : details is empty for record number ".$res['id']);
                                                }

                                                $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                if($res['total']< 0)
                                                        $str .= str_pad($res['contact_id'],15," ",STR_PAD_LEFT);
                                                else
                                                {
                                                        if($res['ptype'] == 'cash')
                                                                $str .= str_pad($this->CashFundCard,15," ",STR_PAD_LEFT); 
                                                        else 
                                                        {
                                                                if($res['ptype'] == 'Ypay' || $res['ptype'] == 'credit')
                                                                        $str .= str_pad($this->CardCreditFund,15," ",STR_PAD_LEFT); 
                                                                else
                                                                        $str .= str_pad(" ",15," ",STR_PAD_LEFT); 
                                                        }
                                                }

                                                $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                $str .= str_pad(" ",15," ",STR_PAD_LEFT); 

                                                $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                if($res['total']< 0)
                                                {

                                                        if($res['ptype'] == 'cash')
                                                                $str .= str_pad($this->CashFundCard,15," ",STR_PAD_LEFT); 
                                                        else 
                                                        {
                                                                if($res['ptype'] == 'Ypay' || $res['ptype'] == 'credit')
                                                                        $str .= str_pad($this->CardCreditFund,15," ",STR_PAD_LEFT); 
                                                                else
                                                                        $str .= str_pad(" ",15," ",STR_PAD_LEFT); 
                                                        }						
                                                }
                                                else
                                                        $str .= str_pad($res['contact_id'],15," ",STR_PAD_LEFT);

                                                $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                $str .= str_pad(" ",15," ",STR_PAD_LEFT); 

                                                $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                if($res['currency'] == 'ILS') 
                                                {
                                                    $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total']))),11," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",11," ",STR_PAD_LEFT); 

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total']))),11," ",STR_PAD_LEFT);
                                                    
                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",9," ",STR_PAD_LEFT); 

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                }
                                                else
                                                {
                                                    $str .= str_pad(" ",11," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",11," ",STR_PAD_LEFT); 

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",11," ",STR_PAD_LEFT); 

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",9," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                }


                                                if($res['currency'] != 'ILS') 
                                                {
                                                    $str .= str_pad(" ",11," ",STR_PAD_LEFT); 

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total']))),11," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",11," ",STR_PAD_LEFT); 

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total']))),11," ",STR_PAD_LEFT);
                                                }
                                                else
                                                {
                                                    $str .= str_pad(" ",11," ",STR_PAD_LEFT); 

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",11," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",11," ",STR_PAD_LEFT); 

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",11," ",STR_PAD_LEFT);
                                                }

                                                $str .= "\r\n";
                                            }
                                            else
                                            {
                                                if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : serial_number is empty for record number ".$res['id']);
                                            }
					}
				}
			}
			fwrite($fp, $str);
			fclose($fp);
                        
                        if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : file generation for movein for receipts ended ");
		}

	   }catch(Exception $ex)
	   {
                 echo "Exception thrown :";
                 echo $ex->getMessage();
                 if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Exception thrown : ".$ex->getMessage());
	   }

	}
  }

?>
