<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


    /***********************Global variables*******************************/
	$path='output/';
        $configpath = 'config/config.php';        
        include_once('lib/log4php/src/main/php/Logger.php');
        include_once "models.php";
        Logger::configure('lib/log4php/config.xml');
   /**************************************************************/

  class Moveininvoice{
      
      
        public $error_array = array(
            "account_key_missing"=>"בכל תנועה חייב להיות לפחות מפתח חשבון חובה או מפתח חשבון זכות.",
            "fee_missing"=>"אי אפשר להעביר תנועות ללא סכום.",
            "total_missing"=>"בכל תנועה חייב להיות לפחות סכום אחד.",
            "funds_account_mismatch"=>"לכל סכום שמועבר חייב להיות חשבון בהתאמה, אבל אפשר להעביר חשבונות ללא סכומים (חשבונות אינפורמטיביים).",
            "total_duty_total_right_mismatch"=>"כאשר בתנועה יש גם סכום בחובה וגם סכום בזכות התנועה חייבת להיות מאוזנת (סך חובה = סך זכות). תנועה מאוזנת היא תנועה שסך הסכומים בחובה שווה לסך הסכומים בזכות.",
            "dates_not_valid"=>"תאריכי הערך והאסמכתא חייבים להיות בגבולות התאריכים שהמשתמש הגדיר בסעיף הגדרות חברה בתפריט הגדרות.",
            "label_only_movement"=>"סוג התנועה משמש כסימון בלבד ואינו קובע את פיצול התנועה."
        );

	private $query;
        private $root;
        private $log;
        public $CardTransactions,$VATTicketDeals,$CashFundCard,$CardCreditFund,$stopProcess,$error;
        
        public function __construct()
        {
            // The __CLASS__ constant holds the class name
            $this->log = Logger::getLogger(__CLASS__);
        }
        /*
         *  connect to the database
         */
	public function connect(){
          $log = $this->log;
	  include($GLOBALS['configpath']);	
          if(!$logon)
          {
              $log = null;
          }
          
	  if(isset($dbconfig['dbusername']) && !empty($dbconfig['dbusername']))
	  {
	  	$user = $dbconfig['dbusername']; 
	  }
          else 
	  {
               echo "Database username is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database username is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbpassword']) && !empty($dbconfig['dbpassword']))
	  {
	  	$pass = $dbconfig['dbpassword'];
	  }
          else 
	  {
               echo "Database password is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database password is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbname']) && !empty($dbconfig['dbname']))
	  {
	  	$dbname = $dbconfig['dbname'];
	  }
          else 
	  {
               echo "Database name is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database name is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbhost']) && !empty($dbconfig['dbhost']))
	  {
	  	$dbhost = $dbconfig['dbhost'];
	  }
          else 
	  {
               echo "Database host is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database host is not set. Please check the config."); 
               die();
	  }
          try{
		  $dbh = new PDO('mysql:host='.$dbhost.';dbname='.$dbname, $user, $pass);
                  if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : database connection created ");
		  return $dbh;
          }catch(Exception $ex)
	  {
                 echo "Exception thrown :";
                 echo $ex->getMessage();
                if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Exception thrown : ".$ex->getMessage()); 
		die();
	  }
       	}

        
        
        
           /**
         *
         * Geneate heshin with time of created at, this is a filter which can be used to 
         * get data according to Date and ids 
         *
         * @param $startDate
         * @param $endDate
         * @param  $startId
         * @param $endId 
         * @param $getpointer 
         *
         * @return mixed , if $getpointer is set then filepointer(handler resource), 
         * if $genpointer is false it will send string back   , but if error encountered it will return false;
         */ 


      function moveininvoicewithDateandtime($startDate=null,$endDate=null,$startId=null,$endId=null,$getpointer){
                      $where = false;
                     $query =   " select * from document " ;

                     if(!is_null($startDate)) $startDateString = " created_at > '$startDate'";
                     else  $startDateString = null;

                     if(!is_null($endDate)) $endDateString = " created_at < '$endDate'";
                     else $endDateString = null;


                     if(!is_null($startId)) $startIdString = " id > $startId";
                     else  $startIdString = null;

                     if(!is_null($endId)) $endIdString = " id < $endId";
                     else $endIdString = null;

                     if(is_string($startDateString)) {
                     $query .= " where $startDateString";
                     $where = true;
                     }
                     
                     if(is_string($endDateString))
                     if(!$where) {
                     $query .= " where $endDateString";
                      $where = true;
                     }else $query .=" and $endDateString";
                       
                     if(is_string($startIdString))
                      if( !$where) {
                     $query .= " where $startIdString";
                      $where = true;
                     }else $query .=" and $startIdString";

                     if(is_string($endIdString))
                      if( !$where) {
                     $query .= " where $endIdString";
                      $where = true;
                     }else $query .=" and $endIdString";

                   try{
                       // Connect 
                      
                       $con = $this->connect();
                       $this->query = $query;

                      // echo $query;
                       $con->query("SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', 					character_set_database = 'utf8', character_set_server = 'utf8'"); 
                       // Set query and fetch data as contact class , built in pdo function
                       $results = $con->query($query);
                        $results=$results->fetchAll(PDO::FETCH_CLASS,"document");
                        
                        
                      //  print_r($results);
                     
                     //  $result = $result->fetchAll(PDO::FETCH_CLASS,"contact");
                       
                       return $this->generatemoveininvoiceWithString($results,$getpointer);

                   }catch(Exception  $e ){
                           echo "Error: ".$e;
                           if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Error: ".$e);
                           die();
                   }  

      }
      
      
      
       /**
         *
         * generating string which contains the heshin 
         *
         * @param mixed $result an array of results for example array(0=>$row1){Multidimentional array}

         *
         * @return string $str , readymade heshinfile string
         */    
        
        function useArrayToGenerateString($result){
            $str="";
            $string = ""; 
            
            
           
            foreach($result as $oneresult)
			{ 
                                               

                              if(is_object($oneresult)) {
                                 
                                  if(!$oneresult->checkandSetMissingData()){
                                      $this->stopProcess = true;
                                      $this->error =$oneresult->error;
                                       
                                      return false;
                                  }
                                    
                                    $res = $oneresult->getDataArray();
                              }
                              else {
                                  $newdata = new Document();
                                  
                                  $newdata->setDataArray($oneresult);
                                   if(!$newdata->checkandSetMissingData()){
                                      $this->stopProcess = true;
                                      $this->error =$newdata->error;
                                      return false;
                                  }
                                  $res = $newdata->getDataArray();
                                  
                              }
                               
                               $string = $this->generateImoveinInvoiceString($res,true);
                               
                               
                               
                               if(is_string($string)){
                                    $str .=  $string;
                                   
                               }else{
                                  
                                   return $string;
                               }
			}
                        
                        return $str;
            
        }
        
      
       /**
          *
          * generating string or temperary file , which contains the heshin , call this if you have an 
         * array of data , it will require the array to be indexed with element at 0 pointer 
          *
          * @param mixed $result an array of results or a single result in the form of an array
          *  for example array(0=>$row1){Multidimentional array} , or $row1 single dimension array 
          * @param boolean $getpointer     
          *
          * @return mixed , if $getpointer is set then filepointer(handler resource), 
          * if $genpointer is false it will send string back   , but if error encountered it will return false;
          */    

        function generatemoveininvoiceWithString($result = array(),$getpointer=true){
            
           
                //Return file pointer to caller 
                $str="";
		if(is_array($result) // check if results are supplied to us
                        && 
                        !array_key_exists("serial_number",$result)) 
		{
               
                
                        $str = $this->useArrayToGenerateString($result);
                         
                }else{
                    if(is_array($result)) {//even a single object has to be an array with keys
                        
                       
                        $newdata = new Document();    
                      
                        if(is_object($result))    $newdata = $result;      
                         else $newdata->setDataArray($result);
                         
                          if(!$newdata->checkandSetMissingData())
                                       return false;
                          
                          
                          $res  = $newdata->getDataArray();
                        $str = generateMoveininvoiceString($res);
                       
                   
                    }
                }
               
            if($getpointer && !$this->stopProcess){
                $temp = fopen("/tmp/asdasd","w+");
               
                fwrite($temp, $str);
                return $temp;
            }else return $str;
            
        }
        
        
         /*
         *  generate movein for invoice
         */
	public function generateMoveinInvoice(){

          try{
                $log = $this->log;
                
                if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : file generation for movein for invoices started ");
                 
		include($GLOBALS['configpath']);	

		 if(isset($outputcfg['outputpath']) && !empty($outputcfg['outputpath']))
		 	$this->root =$outputcfg['outputpath'];
		 else
		 	$this->root =$GLOBALS['path'];

                 if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : output location : ".$this->root);
                 
		 if(!is_dir($this->root))
			mkdir($this->root, 0777,true);
	    
		 if(isset($outputcfg['invoicemoveinfilename']) && !empty($outputcfg['invoicemoveinfilename']))
		 	$file = $outputcfg['invoicemoveinfilename'];
		 else
		 	$file = 'moveininvoice.dat';

                 if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : movein for invoice filename : ".$file);
                 
		 $filepath = $this->root.$file;
		    
		 if(file_exists($filepath))
		 {
			unlink($filepath);  
			$fp = fopen($filepath, "w");            
		 }
		 else 
		 {
			$fp = fopen($filepath, "w");
		 }
                try{                    
                    $con = $this->connect();
                    $this->query = 'select * from document';
                    $con->query("SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', 					character_set_database = 'utf8', character_set_server = 'utf8'"); 
                    $result = $con->query($this->query)->fetchAll(PDO::FETCH_CLASS,"document");  
                    
               	}catch(PDOException  $e ){
			echo "Error: ".$e;
                        if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Error: ".$e);
			die();
		}  
                
		$str="";
		if($result)
		{
			foreach($result as $res)
			{ 
                            $res = $res->getArray();
                            $str.=$this->generateImoveinInvoiceString($res, false);
			}
			fwrite($fp, $str);
			fclose($fp);
                        if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : file generation for movein for invoices ended ");
		}

	   }catch(Exception $ex)
	   {
                 echo "Exception thrown :";
                 echo $ex->getMessage();
                 if(is_object($log)) $log->error("Exception thrown : ".$ex->getMessage());
	   }

	}
        
        
        
          /**
        *
        * Check for valid heshinArray , check if single row contains all data 
        *
        * @param array $res a single result in the form of an array
        * @param boolean $object  whether data was derived from a contact object  
        *
        * @return true , is array was generated by object , else check the validity of the data 
         * if invalid set the message as the error ,and return false to stop the generation 
        */    
        function checkImoveinInvoiceArray($res,$object){
            $newdata = new Document();
              
            $newdata->setDataArray($res);
            if(!$newdata->checkandSetMissingData() && !$object){
                $this->error = $newdata->error;
                return false;
            }else{
              return true;
            }
        }
        
         /**
          *
          * Generate a single record based format , generate line for one record 
          * 
          * the string are literally generates by joining , parts and spaces to make the heshin string , appended by /r/n (carrige return and newline)
          * Other function use these string together to make a large file which can be used
          * @param array $res a single result in the form of an array
          * @param boolean $object  whether data was derived from a contact object  
          *
          * @return string $str , this is single record coverted to heshin format 
          */  
        
        
        
        function generateImoveinInvoiceString($res,$object=true){
            $str = "";
            $log = $this->log;
            
          if(!$this->checkImoveinInvoiceArray($res,$object)){
                return false;
            }
            if($res['type'] == 'income')
				{
					if($res['document_type'] == 'tax_invoice' || $res['document_type'] == 'invoice_receipt'|| $res['document_type'] == 'credit_invoice') // Process if the document matches these type
					{						
						if(!empty($res['serial_number'])) // if the seieal number empty do not process since this document does not have document name
                                                {
                                                    $str .= str_pad(" ",5," ",STR_PAD_LEFT); // 5 blank spaces
                                                    
                                                    // type_move_param if exists put in it , else put blank spaces 
                                                    if(!empty($res['type_move_param'])){
                                                    $str .= str_pad($res['type_move_param'],3," ",STR_PAD_LEFT);
                                                    }else
                                                    $str .= str_pad(" ",3," ",STR_PAD_LEFT);

                                                      // Serial Number   
                                                    $str .= str_pad($res['serial_number'],9," ",STR_PAD_LEFT);
                                               
                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                    if(!empty($res['created_at']))
                                                        $str .= str_pad(substr(strftime("%d/%m/%y",strtotime($res['created_at'])),0,10),10," ",STR_PAD_LEFT);
                                                    else{
                                                            $str .= str_pad(substr(strftime("%d/%m/%y",strtotime($res['created_at'])),0,10),10," ",STR_PAD_LEFT);
                                                        if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : created_at is empty for record number ".$res['id']);
                                                    }
                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                    if(!empty($res['produced_at']))
                                                        $str .= str_pad(substr(strftime("%d/%m/%y",strtotime($res['produced_at'])),0,10),10," ",STR_PAD_LEFT);
                                                    else{
                                                            $str .= str_pad(substr(strftime("%d/%m/%y",strtotime($res['produced_at'])),0,10),10," ",STR_PAD_LEFT);
                                                        if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : produced_at is empty for record number ".$res['id']);
                                                    }
                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    if(!empty($res['details']) )
                                                    { 
                                                            $tempbefore = iconv('UTF-8','Windows-1255//TRANSLIT',$res['details']);
                                                            $temp = strrev($tempbefore);
                                                            $str .= str_pad(substr($temp,0,20),20," ",STR_PAD_LEFT);
                                                     }else{
                                                            $str .= str_pad(" ",20," ",STR_PAD_LEFT);
                                                            if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : details is empty for record number ".$res['id']);
                                                    }

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    if($res['total']< 0)
                                                            $str .= str_pad($this->CardTransactions,15," ",STR_PAD_LEFT); // will be given later***
                                                    else
                                                            $str .= str_pad($res['contact_id'],15," ",STR_PAD_LEFT);

                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                    if($res['total']< 0)
                                                            $str .= str_pad($this->VATTicketDeals,15," ",STR_PAD_LEFT); // will be given later*
                                                    else
                                                            $str .= str_pad(" ",15," ",STR_PAD_LEFT);
                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                    if($res['total']< 0)
                                                            $str .= str_pad($res['contact_id'],15," ",STR_PAD_LEFT); 
                                                    else
                                                            $str .= str_pad($this->CardTransactions,15," ",STR_PAD_LEFT); // will be given later***
                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                    if($res['total']< 0)
                                                            $str .= str_pad(" ",15," ",STR_PAD_LEFT); 
                                                    else
                                                            $str .= str_pad($this->VATTicketDeals,15," ",STR_PAD_LEFT); // will be given later*
                                                    $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                    if($res['currency'] == 'ILS')
                                                    {
                                                        if($res['total']< 0)
                                                                $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total_before']))),15," ",STR_PAD_LEFT); 
                                                        else
                                                                $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total']))),15," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                        if($res['total']< 0)
                                                                $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['vat']))),9," ",STR_PAD_LEFT); 
                                                        else
                                                                $str .= str_pad(" ",9," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                        if($res['total']< 0)
                                                                $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total']))),9," ",STR_PAD_LEFT); 
                                                        else
                                                                $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total_before']))),9," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                        if($res['total']< 0)
                                                                $str .= str_pad(" ",9," ",STR_PAD_LEFT); 
                                                        else
                                                                $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['vat']))),9," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                    }
                                                    else 
                                                    {
                                                        $str .= str_pad(" ",15," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                        $str .= str_pad(" ",9," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                        $str .= str_pad(" ",9," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                        $str .= str_pad(" ",9," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                    }

                                                    if($res['currency'] != 'ILS')
                                                    {
                                                        if($res['total']< 0)
                                                            $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total_before']))),11," ",STR_PAD_LEFT); 
                                                        else
                                                                $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total']))),11," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                        if($res['total']< 0)
                                                                $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['vat']))),11," ",STR_PAD_LEFT); 
                                                        else
                                                                $str .= str_pad(" ",11," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                        if($res['total']< 0)
                                                                $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total']))),11," ",STR_PAD_LEFT); 
                                                        else
                                                                $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['total_before']))),11," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                                        if($res['total']< 0)
                                                                $str .= str_pad(" ",11," ",STR_PAD_LEFT); 
                                                        else
                                                                $str .= str_pad(str_replace('.','',sprintf("%01.2f",abs($res['vat']))),11," ",STR_PAD_LEFT); 
                                                    }
                                                    else 
                                                    {
                                                        $str .= str_pad(" ",11," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                        $str .= str_pad(" ",11," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                        $str .= str_pad(" ",11," ",STR_PAD_LEFT); 
                                                        $str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                                        $str .= str_pad(" ",11," ",STR_PAD_LEFT); 
                                                    }
                                                    
                                                    $str .= "\r\n";
                                                } 
                                                else{
                                                        if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : serial_number is empty for record number ".$res['id']);
                                                }
                                                
						
					}
				}
                                return $str;
            
        }
  }