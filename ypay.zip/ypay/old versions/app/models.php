<?php

/*
 *  Small Style ORM layer to be used to override the existing items
 *  To be used with config to make changes configs are alow allowed to be overridden on the runtime 
 *  Each result row is represented by class below , contact is for contact ->hashin.dat
 *  Document is for document -> Moveinmoveininvoice
 *  Document_receipt is for ->moveinreceipt
 * 
 *  
 */

 $configpath = 'config/config.php'; 

class Contact {
  
    
    
    
public $error;
public $id;
public $type;
public $name;
public $balance;
public $comments;
public $city_id;
public $business_number;
public $address;
public $phone;
public $email;
public $website;
public $zipcode;
public $mobile;
public $created_at;
public $updated_at;
public $percentage_withholding;
  public $error_array = array(
            "account_key_missing"=>"בכל תנועה חייב להיות לפחות מפתח חשבון חובה או מפתח חשבון זכות.",
            "fee_missing"=>"אי אפשר להעביר תנועות ללא סכום.",
            "total_missing"=>"בכל תנועה חייב להיות לפחות סכום אחד.",
            "funds_account_mismatch"=>"לכל סכום שמועבר חייב להיות חשבון בהתאמה, אבל אפשר להעביר חשבונות ללא סכומים (חשבונות אינפורמטיביים).",
            "total_duty_total_right_mismatch"=>"כאשר בתנועה יש גם סכום בחובה וגם סכום בזכות התנועה חייבת להיות מאוזנת (סך חובה = סך זכות). תנועה מאוזנת היא תנועה שסך הסכומים בחובה שווה לסך הסכומים בזכות.",
            "dates_not_valid"=>"תאריכי הערך והאסמכתא חייבים להיות בגבולות התאריכים שהמשתמש הגדיר בסעיף הגדרות חברה בתפריט הגדרות.",
            "label_only_movement"=>"סוג התנועה משמש כסימון בלבד ואינו קובע את פיצול התנועה."
        );
public $datachecker = array(
                 'id'=>array("errorval"=>"account_key_missing","validate"=>true),
                'type'=>array("errorval"=>"account_key_missing","validate"=>true),
                'name'=>array("errorval"=>"account_key_missing","validate"=>true),
                'balance'=>array("errorval"=>"account_key_missing","validate"=>false),
                'comments'=>array("errorval"=>"account_key_missing","validate"=>false),
                'city_id'=>array("errorval"=>"account_key_missing","validate"=>false),
                'business_number'=>array("errorval"=>"account_key_missing","validate"=>false),
                'address'=>array("errorval"=>"account_key_missing","validate"=>false),
                'phone'=>array("errorval"=>"account_key_missing","validate"=>false),
                'email'=>array("errorval"=>"account_key_missing","validate"=>false),
                'website'=>array("errorval"=>"account_key_missing","validate"=>false),
                'zipcode'=>array("errorval"=>"account_key_missing","validate"=>false),
                'mobile'=>array("errorval"=>"account_key_missing","validate"=>false),
                'created_at'=>array("errorval"=>"account_key_missing","validate"=>false),
                'updated_at'=>array("errorval"=>"account_key_missing","validate"=>false),
                "percentage_withholding"=>array("errorval"=>"account_key_missing","validate"=>false),
    
);




    public function connect(){
          
	  include($GLOBALS['configpath']);	
          
          
	  if(isset($dbconfig['dbusername']) && !empty($dbconfig['dbusername']))
	  {
	  	$user = $dbconfig['dbusername']; 
	  }
          else 
	  {
               echo "Database username is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database username is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbpassword']) && !empty($dbconfig['dbpassword']))
	  {
	  	$pass = $dbconfig['dbpassword'];
	  }
          else 
	  {
               echo "Database password is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database password is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbname']) && !empty($dbconfig['dbname']))
	  {
	  	$dbname = $dbconfig['dbname'];
	  }
          else 
	  {
               echo "Database name is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database name is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbhost']) && !empty($dbconfig['dbhost']))
	  {
	  	$dbhost = $dbconfig['dbhost'];
	  }
          else 
	  {
               echo "Database host is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database host is not set. Please check the config."); 
               die();
	  }
          try{
		  $dbh = new PDO('mysql:host='.$dbhost.';dbname='.$dbname, $user, $pass);
                  if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : database connection created ");
		  return $dbh;
          }catch(Exception $ex)
	  {
                 echo "Exception thrown :";
                 echo $ex->getMessage();
                if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Exception thrown : ".$ex->getMessage()); 
		die();
	  }
       	}
/**
  * if id is set get data and check existing data , if data is missing populate from database 
  *
  * @param void  
  *
  * @return void  
  */ 
    
    
    function buildDataagain(){
        if(!is_null(is_int($this->id)) && is_int($this->id)){
            $query = "select * from contact where id = {$this->id}";
            $con = $this->connect();
            $con->query($query);
            $result = $con->query($this->query)->fetch(PDO::FETCH_ASSOC);
            
            if(is_bool($result)) return false; 
            
          
            foreach($result as $key => $value ){
                if(!isset($this->$key) || empty($this->$key))
                    $this->$key = $value;
                    
                
            }
            
            
            return true;
            
        }else return false;
        
        
    }
     
        
  

     /**
  *Check one row , if id is set and data is missing this will fetch data from the database and populate it  
  *
  * @param void  
  *
  * @return boolean  if any data is missing , then false , if data is proper true
  */    

    function checkandSetMissingData(){
        foreach($this->datachecker as $key =>$value){
            if($this->checkData($key)) continue;
            else {
                $this->buildDataagain();
                
                foreach($this->datachecker as $keyx =>$valuex){
                    if($this->checkData($key)) continue;
                     else return false;
                }
                
                
                
            }
        }
        return true;   
    }

    
  /**
  * Any extra processing to make changes object wide or dependent of data 
  *
  * @param void  
  *
  * @return void
  */ 

    function doProcessingOfData(){
        //Make all changing here this is where the process for data will happen;
        
    }
    
    
         
  /**
  * check this object if any item is missing 
  *
  * @param void  
  *
  * @return boolean if any key is missing which is required it will return false
  */ 
     
    function checkData($key){
       if((empty($this->$key) || is_null($this->$key) )&& $this->datachecker[$key]["validate"])
       {
           $this->error = $this->error_array[$this->datachecker[$key]["errorval"]];
         
           return false;
       }
        return true;
    }
     /**
  *Convert from array to this objet properties 
  *
  * @param void  
  *
  * @return array Associative array of all columns
  */ 
     
    
    
    function setDataArray($array){
        foreach($array as $key => $value){
          
            $this->$key  = $value;
        }
    }
    
    /**
  *Convert from object to array 
  *
  * @param void  
  *
  * @return array Associative array of all columns
  */ 
    

    function getDataArray(){
        
        
        
        $this->doProcessingOfData();
        return array(
                'id'=>$this->id,
                'type'=>$this->type,
                'name'=>$this->name,
                'balance'=>$this->balance,
                'comments'=>$this->comments,
                'city_id'=>$this->city_id,
                'business_number'=>$this->business_number,
                'address'=>$this->address,
                'phone'=>$this->phone,
                'email'=>$this->email,
                'website'=>$this->website,
                'zipcode'=>$this->zipcode,
                'mobile'=>$this->mobile,
                'created_at'=>$this->created_at,
                'updated_at'=>$this->updated_at,
                "percentage_withholding"=>$this->percentage_withholding
        );
        
    }

    

    

}

class document {
    
public $id;
public $type;
public $type_move_param;
public $contact_id;
public $document_type;
public $is_manual;
public $is_recurring;
public $is_closed;
public $is_template;
public $is_rounding;
public $serial_number;
public $details;
public $total_before;
public $total;
public $vat;
public $currency;
public $currency_rate;
public $lang;
public $produced_at;
public $created_at;
public $updated_at;

  public $error_array = array(
            "account_key_missing"=>"בכל תנועה חייב להיות לפחות מפתח חשבון חובה או מפתח חשבון זכות.",
            "fee_missing"=>"אי אפשר להעביר תנועות ללא סכום.",
            "total_missing"=>"בכל תנועה חייב להיות לפחות סכום אחד.",
            "funds_account_mismatch"=>"לכל סכום שמועבר חייב להיות חשבון בהתאמה, אבל אפשר להעביר חשבונות ללא סכומים (חשבונות אינפורמטיביים).",
            "total_duty_total_right_mismatch"=>"כאשר בתנועה יש גם סכום בחובה וגם סכום בזכות התנועה חייבת להיות מאוזנת (סך חובה = סך זכות). תנועה מאוזנת היא תנועה שסך הסכומים בחובה שווה לסך הסכומים בזכות.",
            "dates_not_valid"=>"תאריכי הערך והאסמכתא חייבים להיות בגבולות התאריכים שהמשתמש הגדיר בסעיף הגדרות חברה בתפריט הגדרות.",
            "label_only_movement"=>"סוג התנועה משמש כסימון בלבד ואינו קובע את פיצול התנועה."
        );

  // Use these two arrays to make errors meaningful , bottom array uses fields , you can validate 
  //Their existing by setting them at the bottm , the errorval is from error array , if the validate is set to true , 
  // and the value is empty , then erroval will be used to look up error array and return that error
  
  
public $datachecker = array(
                'id'=>array("errorval"=>"idmising","validate"=>false),
                'type'=>array("errorval"=>"typemissing","validate"=>false),
                'contact_id'=>array("errorval"=>"contactmissing","validate"=>true),
                'document_type'=>array("errorval"=>"idmising","validate"=>false),
                'is_manual'=>array("errorval"=>"idmising","validate"=>false),
                'is_recurring'=>array("errorval"=>"idmising","validate"=>false),
                'is_closed'=>array("errorval"=>"idmising","validate"=>false),
                'is_template'=>array("errorval"=>"idmising","validate"=>false),
                'is_rounding'=>array("errorval"=>"idmising","validate"=>false),
                'serial_number'=>array("errorval"=>"documissing","validate"=>true),
                'details'=>array("errorval"=>"detailsmissing","validate"=>false),
                'total_before'=>array("errorval"=>"total_missing","validate"=>true),
                'total'=>array("errorval"=>"total_missinfg","validate"=>true),
                'vat'=>array("errorval"=>"vat_missing","validate"=>true),
                'currency'=>array("errorval"=>"currencymiss","validate"=>true),
                'currency_rate'=>array("errorval"=>"idmising","validate"=>true),
                'lang'=>array("errorval"=>"idmising","validate"=>true),
                'produced_at'=>array("errorval"=>"idmising","validate"=>true),
                'created_at'=>array("errorval"=>"idmising","validate"=>false),
                'updated_at'=>array("errorval"=>"idmising","validate"=>false),
                "type_move_param"=>array("errorval"=>"idmising","validate"=>false)

);


/**
  * Any extra processing to make changes object wide or dependent of data 
  *
  * @param void  
  *
  * @return void
  */ 

    
    function doProcessingOfData(){
        //Make all changing here this is where the process for data will happen;
       $this->id = "200";
        
        
    }
    
    
    
      
  /**
  * check this object if any item is missing 
  *
  * @param void  
  *
  * @return boolean if any key is missing which is required it will return false
  */ 
     
    
    function checkData($key){
       if((empty($this->$key) || is_null($this->$key) )&& $this->datachecker[$key]["validate"])
       {
           $this->error =  $this->error_array[$this->datachecker[$key]["errorval"]];
         
           return false;
       }
        return true;
    }
    
    
  /**
  *Convert from array to this objet properties 
  *
  * @param void  
  *
  * @return array Associative array of all columns
  */ 
     
    function setDataArray($array){
        foreach($array as $key => $value){
          
            $this->$key  = $value;
        }
    }
    
    
    
          
 
    
    
        
  /**
  *Check one row , if id is set and data is missing this will fetch data from the database and populate it  
  *
  * @param void  
  *
  * @return boolean  if any data is missing , then false , if data is proper true
  */    

    function checkandSetMissingData(){
        foreach($this->datachecker as $key =>$value){
            if($this->checkData($key)) continue;
            else {
                $this->buildDataagain();
                
                foreach($this->datachecker as $keyx =>$valuex){
                    if($this->checkData($key)) continue;
                     else return false;
                }
                
                
                
            }
        }
        return true;   
    }
    
 /**
  *Convert from object to array 
  *
  * @param void  
  *
  * @return array Associative array of all columns
  */ 
    
    function getDataArray(){
      $this->doProcessingOfData();
        return array(
            
                'id'=>$this->id,
                'type'=>$this->type,
                'contact_id'=>$this->contact_id,
                'document_type'=>$this->document_type,
                'is_manual'=>$this->is_manual,
                'is_recurring'=>$this->is_recurring,
                'is_closed'=>$this->is_closed,
                'is_template'=>$this->is_template,
                'is_rounding'=>$this->is_rounding,
                'serial_number'=>$this->serial_number,
                'details'=>$this->details,
                'total_before'=>$this->total_before,
                'total'=>$this->total,
                'vat'=>$this->vat,
                'currency'=>$this->currency,
                'currency_rate'=>$this->currency_rate,
                'lang'=>$this->lang,
                'produced_at'=>$this->produced_at,
                'created_at'=>$this->created_at,
                'updated_at'=>$this->updated_at,
                "type_move_param"=>$this->type_move_param

            
        );
        
    }
    
    
    public function connect(){
          
	  include($GLOBALS['configpath']);	
          
          
	  if(isset($dbconfig['dbusername']) && !empty($dbconfig['dbusername']))
	  {
	  	$user = $dbconfig['dbusername']; 
	  }
          else 
	  {
               echo "Database username is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database username is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbpassword']) && !empty($dbconfig['dbpassword']))
	  {
	  	$pass = $dbconfig['dbpassword'];
	  }
          else 
	  {
               echo "Database password is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database password is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbname']) && !empty($dbconfig['dbname']))
	  {
	  	$dbname = $dbconfig['dbname'];
	  }
          else 
	  {
               echo "Database name is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database name is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbhost']) && !empty($dbconfig['dbhost']))
	  {
	  	$dbhost = $dbconfig['dbhost'];
	  }
          else 
	  {
               echo "Database host is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database host is not set. Please check the config."); 
               die();
	  }
          try{
		  $dbh = new PDO('mysql:host='.$dbhost.';dbname='.$dbname, $user, $pass);
                  if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : database connection created ");
		  return $dbh;
          }catch(Exception $ex)
	  {
                 echo "Exception thrown :";
                 echo $ex->getMessage();
                if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Exception thrown : ".$ex->getMessage()); 
		die();
	  }
       	}
/**
  * if id is set get data and check existing data , if data is missing populate from database 
  *
  * @param void  
  *
  * @return void  
  */ 
    
    
    function buildDataagain(){
        if(!is_null(is_int($this->id)) && is_int($this->id)){
            $query = "select * from document where id = {$this->id}";
            $con = $this->connect();
            $con->query($query);
            $result = $con->query($this->query)->fetch(PDO::FETCH_ASSOC);
            
            if(is_bool($result)) return false; 
            
          
            foreach($result as $key => $value ){
                if(!isset($this->$key) || empty($this->$key))
                    $this->$key = $value;
                    
                
            }
            
            
            return true;
            
        }else return false;
        
        
    }
}


class document_receipt extends document{
    
    public $payment_id;
    public $type;
     
      public $error_array = array(
            "account_key_missing"=>"בכל תנועה חייב להיות לפחות מפתח חשבון חובה או מפתח חשבון זכות.",
            "fee_missing"=>"אי אפשר להעביר תנועות ללא סכום.",
            "total_missing"=>"בכל תנועה חייב להיות לפחות סכום אחד.",
            "funds_account_mismatch"=>"לכל סכום שמועבר חייב להיות חשבון בהתאמה, אבל אפשר להעביר חשבונות ללא סכומים (חשבונות אינפורמטיביים).",
            "total_duty_total_right_mismatch"=>"כאשר בתנועה יש גם סכום בחובה וגם סכום בזכות התנועה חייבת להיות מאוזנת (סך חובה = סך זכות). תנועה מאוזנת היא תנועה שסך הסכומים בחובה שווה לסך הסכומים בזכות.",
            "dates_not_valid"=>"תאריכי הערך והאסמכתא חייבים להיות בגבולות התאריכים שהמשתמש הגדיר בסעיף הגדרות חברה בתפריט הגדרות.",
            "label_only_movement"=>"סוג התנועה משמש כסימון בלבד ואינו קובע את פיצול התנועה."
        );
    
    
    function doProcessingOfData(){
        //Make all changing here this is where the process for data will happen;
       $this->id = "200";
        
        
    }
    
    
  /**
  *Convert from object to array 
  *
  * @param void  
  *
  * @return array Associative array of all columns
  */ 
    function getDataArray(){
        $this->doProcessingOfData();
        return array(
            
                'id'=>$this->id,
                'type'=>$this->type,
                'contact_id'=>$this->contact_id,
                'document_type'=>$this->document_type,
                'is_manual'=>$this->is_manual,
                'is_recurring'=>$this->is_recurring,
                'is_closed'=>$this->is_closed,
                'is_template'=>$this->is_template,
                'is_rounding'=>$this->is_rounding,
                'serial_number'=>$this->serial_number,
                'details'=>$this->details,
                'total_before'=>$this->total_before,
                'total'=>$this->total,
                'vat'=>$this->vat,
                'currency'=>$this->currency,
                'currency_rate'=>$this->currency_rate,
                'lang'=>$this->lang,
                'produced_at'=>$this->produced_at,
                'created_at'=>$this->created_at,
                'updated_at'=>$this->updated_at,
                'payment_id'=>$this->payment_id,
                'ptype'=>$this->ptype
            
        );
        
    }
    
 /**
  * if id is set get data and check existing data , if data is missing populate from database 
  *
  * @param void  
  *
  * @return void  
  */ 
    
    
    function buildDataagain(){
        if(!is_null(is_int($this->id)) && is_int($this->id)){
            $query = "select d.*, p.payment_id, p.type as ptype from document as d inner join payment_method as p on d.id = p.payment_id  where d.id = {$this->id}";
            $con = $this->connect();
            $con->query($query);
            $result = $con->query($this->query)->fetch(PDO::FETCH_ASSOC);
            
            if(is_bool($result)) return false; 
            
          
            foreach($result as $key => $value ){
                if(!isset($this->$key) || empty($this->$key))
                    $this->$key = $value;
                    
                
            }
            
            
            return true;
            
        }else return false;
        
        
    }
    
    
}
