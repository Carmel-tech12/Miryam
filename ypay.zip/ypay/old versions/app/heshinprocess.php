<?php

 
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

	$path='output/';
        $configpath = 'config/config.php';        
        include_once ('lib/log4php/src/main/php/Logger.php');
        include_once     "models.php";
        Logger::configure('lib/log4php/config.xml');
   /**************************************************************/
  
  class Heshinprocess{
        
      
      public $stopProcess = false;
      public $error_array = array(
            "account_key_missing"=>"בכל תנועה חייב להיות לפחות מפתח חשבון חובה או מפתח חשבון זכות.",
            "fee_missing"=>"אי אפשר להעביר תנועות ללא סכום.",
            "total_missing"=>"בכל תנועה חייב להיות לפחות סכום אחד.",
            "funds_account_mismatch"=>"לכל סכום שמועבר חייב להיות חשבון בהתאמה, אבל אפשר להעביר חשבונות ללא סכומים (חשבונות אינפורמטיביים).",
            "total_duty_total_right_mismatch"=>"כאשר בתנועה יש גם סכום בחובה וגם סכום בזכות התנועה חייבת להיות מאוזנת (סך חובה = סך זכות). תנועה מאוזנת היא תנועה שסך הסכומים בחובה שווה לסך הסכומים בזכות.",
            "dates_not_valid"=>"תאריכי הערך והאסמכתא חייבים להיות בגבולות התאריכים שהמשתמש הגדיר בסעיף הגדרות חברה בתפריט הגדרות.",
            "label_only_movement"=>"סוג התנועה משמש כסימון בלבד ואינו קובע את פיצול התנועה."
        );

	private $query;
        private $root;
        private $log;
        public $CardTransactions,$VATTicketDeals,$CashFundCard,$CardCreditFund,$error;
        
         public function __construct()
        {
           
             
            // The __CLASS__ constant holds the class name
             $this->log = Logger::getLogger(__CLASS__);
        }

        /*
         *This is database connection creation method
         *
         * @param void.
         *
         * @return void
         */
	public function connect(){
         
	  include($GLOBALS['configpath']);
         
           //$logon variable to enable and disable logs , 
          //made available for testers to confirm code working 
          if(!$logon) 
          {
              
              
              $log = null;
          }else{
                
            // The __CLASS__ constant holds the class name

            
                $log = $this->log;
          }
          
	  if(isset($dbconfig['dbusername']) && !empty($dbconfig['dbusername']))
	  {
	  	$user = $dbconfig['dbusername']; 
	  }
          else 
	  {
               echo "Database username is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database username is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbpassword']) && !empty($dbconfig['dbpassword']))
	  {
	  	$pass = $dbconfig['dbpassword'];
	  }
          else 
	  {
               echo "Database password is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database password is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbname']) && !empty($dbconfig['dbname']))
	  {
	  	$dbname = $dbconfig['dbname'];
	  }
          else 
	  {
               echo "Database name is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database name is not set. Please check the config."); 
               die();
	  }
	  if(isset($dbconfig['dbhost']) && !empty($dbconfig['dbhost']))
	  {
	  	$dbhost = $dbconfig['dbhost'];
	  }
          else 
	  {
               echo "Database host is not set. Please check the config";
               if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Database host is not set. Please check the config."); 
               die();
	  }
          try{
		  $dbh = new PDO('mysql:host='.$dbhost.';dbname='.$dbname, $user, $pass);
                  if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : database connection created ");
		  return $dbh;
          }catch(Exception $ex)
	  {
                 echo "Exception thrown :";
                 echo $ex->getMessage();
                if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Exception thrown : ".$ex->getMessage()); 
		die();
	  }
          
       	}
        
        /*
         *
         * This method takes data from the database and generates a heshin out of existing data 
         * (Full data set from the tables)
         *
         * @param void.
         *
         * @return void
         */
	public function generateHeshin(){
            
          try{
                $log = $this->log;
                
                if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : file generation for heshin started ");
                
		include($GLOBALS['configpath']);	
                // Set up output path  
		 if(isset($outputcfg['outputpath']) && !empty($outputcfg['outputpath']))
		 	$this->root =$outputcfg['outputpath'];
		 else
		 	$this->root =$GLOBALS['path'];
                 
                 if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : output location : ".$this->root);
                 // Ensure directory as in output path is writatble 
		 if(!is_dir($this->root))
			mkdir($this->root, 0777,true);//@todo make this 755
                // Set up output File name
		 if(isset($outputcfg['hesinfilename']) && !empty($outputcfg['hesinfilename']))
		 	$file = $outputcfg['hesinfilename'];
		 else
		 	$file = 'heshin.dat';
                 
                 if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : heshin filename : ".$file);
                 // Set up output File name and path string
		 $filepath = $this->root.$file;
		    
		 if(file_exists($filepath))
		 {
                      // Delete and recreate the file
			unlink($filepath);  
			$fp = fopen($filepath, "w");            
		 }
		 else 
		 {
                     // create the file
			$fp = fopen($filepath, "w");
		 }

                try{
                    // Connect 
                    $con = $this->connect();
                    $this->query = 'select * from contact';
                    
                    $con->query("SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', 					character_set_database = 'utf8', character_set_server = 'utf8'"); 
                    // Set query and fetch data as contact class , built in pdo function
                    $result = $con->query($this->query)->$result->fetchAll(PDO::FETCH_CLASS,"contact");
                   
               	}catch(PDOException  $e ){
			echo "Error: ".$e;
                        if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Error: ".$e);
			die();
		}  
                 
		$str="";
		if($result && is_array($result))
		{
                    
                        //Generate and create files 
                        $str .= $this->useArrayToGenerateString($result);
			fwrite($fp, $str);
			fclose($fp);
                        if(is_object($log)) $log->info(date('Y-m-d H:i:s')." : file generation for heshin ended ");
		}

	   }catch(Exception $ex)
	   {
                 echo "Exception thrown :";
                 echo $ex->getMessage();
                 if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Exception thrown : ".$ex->getMessage());
	   }

	}
        
        
       
        
        /**
         *
         * Geneate heshin with time of created at, this is a filter which can be used to 
         * get data according to Date and ids 
         *
         * @param $startDate
         * @param $endDate
         * @param  $startId
         * @param $endId 
         * @param $getpointer 
         *
         * @return mixed , if $getpointer is set then filepointer(handler resource), 
         * if $genpointer is false it will send string back   , but if error encountered it will return false;
         */ 


      function heshinwithDateandtime($startDate=null,$endDate=null,$startId=null,$endId=null,$getpointer){
                      $where = false;
                     $query =   " select * from contact " ;
                     
                     if(!$this->isdateValid($startDate)) 
                         die("error");

                     if(!is_null($startDate)) $startDateString = " created_at > '$startDate'";
                     else  $startDateString = null;

                     if(!is_null($endDate)) $endDateString = " created_at < '$endDate'";
                     else $endDateString = null;


                     if(!is_null($startId)) $startIdString = " id > $startId";
                     else  $startIdString = null;

                     if(!is_null($endId)) $endIdString = " id < $endId";
                     else $endIdString = null;

                     if(is_string($startDateString)) {
                     $query .= " where $startDateString";
                     $where = true;
                     }
                     
                     if(is_string($endDateString))
                     if(!$where) {
                     $query .= " where $endDateString";
                      $where = true;
                     }else $query .=" and $endDateString";
                       
                     if(is_string($startIdString))
                      if( !$where) {
                     $query .= " where $startIdString";
                      $where = true;
                     }else $query .=" and $startIdString";

                     if(is_string($endIdString))
                      if( !$where) {
                     $query .= " where $endIdString";
                      $where = true;
                     }else $query .=" and $endIdString";

                   try{
                       // Connect 
                      
                       $con = $this->connect();
                       $this->query = $query;

                      // echo $query;
                       $con->query("SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', 					character_set_database = 'utf8', character_set_server = 'utf8'"); 
                       // Set query and fetch data as contact class , built in pdo function
                       $results = $con->query($query);
                        $results=$results->fetchAll(PDO::FETCH_CLASS,"contact");
                        
                        
                      //  print_r($results);
                     
                     //  $result = $result->fetchAll(PDO::FETCH_CLASS,"contact");
                       
                       return $this->generateHeshinWithString($results,$getpointer);

                   }catch(Exception  $e ){
                           echo "Error: ".$e;
                           if(is_object($log)) $log->error(date('Y-m-d H:i:s')." : Error: ".$e);
                           die();
                   }  

      }
        
        /**
          *
          * generating string or temperary file , which contains the heshin , call this if you have an 
         * array of data , it will require the array to be indexed with element at 0 pointer 
          *
          * @param mixed $result an array of results or a single result in the form of an array
          *  for example array(0=>$row1){Multidimentional array} , or $row1 single dimension array 
          * @param boolean $getpointer     
          *
          * @return mixed , if $getpointer is set then filepointer(handler resource), 
          * if $genpointer is false it will send string back   , but if error encountered it will return false;
          */    

        function generateHeshinWithString($result = array(),$getpointer=true){
            
           
                //Return file pointer to caller 
                $str="";
		if(is_array($result) // check if results are supplied to us
                        && 
                        !array_key_exists("id",$result)) 
		{
               
                
                        $str = $this->useArrayToGenerateString($result);
                         
                }else{
                    if(is_array($result)) {
                    //even a single object has to be an array with keys
                        
                       
                        $newdata = new Contact();    
                        //Convert to object so processes can happen to make changes 
                      
                        if(is_object($result))    $newdata = $result;      
                         else $newdata->setDataArray($result);
                         
                          if(!$newdata->checkandSetMissingData()) //Check if the data is valid 
                                       return false;
                          
                          
                          $res  = $newdata->getDataArray();
                        $str = generateHeshinString($res);
                       
                   
                    }
                }
               
            if($getpointer && !$this->stopProcess){
                $temp = fopen("/tmp/asdasd","w+"); // Temporary File location . Tmpfile breaks so this has been made to happen
               
                fwrite($temp, $str);
                return $temp;
            }else return $str;
            
        }
        
        /**
         *
         * generating string which contains the heshin 
         *
         * @param mixed $result an array of results for example array(0=>$row1){Multidimentional array}

         *
         * @return string $str , readymade heshinfile string
         */    
        
        function useArrayToGenerateString($result){
            $str="";
            $string = ""; 
            
            
           
            foreach($result as $oneresult)
			{ 
                                               

                              if(is_object($oneresult)) {
                                 
                                  if(!$oneresult->checkandSetMissingData()){
                                      $this->stopProcess = true;
                                      $this->error =$oneresult->error;
                                       
                                      return false;
                                  }
                                    
                                    $res = $oneresult->getDataArray();
                              }
                              else {
                                  $newdata = new Contact();
                                  
                                  $newdata->setDataArray($oneresult);
                                   if(!$newdata->checkandSetMissingData()){
                                      $this->stopProcess = true;
                                      $this->error =$newdata->error;
                                      return false;
                                  }
                                    
                                  $res = $newdata->getDataArray();
                                  
                              }
                              
                           
                               
                               $string = $this->generateHeshinString($res,true);
                               
                               
                               
                               if(is_string($string)){
                                    $str .=  $string;
                                   
                               }else{
                                  
                                   return $string;
                               }
			}
                        
                        return $str;
            
        }
        
        
        
        /**
        *
        * Check for valid heshinArray , check if single row contains all data 
        *
        * @param array $res a single result in the form of an array
        * @param boolean $object  whether data was derived from a contact object  
        *
        * @return true , is array was generated by object , else check the validity of the data 
         * if invalid set the message as the error ,and return false to stop the generation 
        */    
        function checkHeshinArray($res,$object){
            $newdata = new Contact();
              
            $newdata->setDataArray($res);
            if(!$newdata->checkandSetMissingData() && !$object){
                $this->error = $newdata->error;
                return false;
            }else{
              return true;
            }
        }
        /**
          *
          * Generate a single record based format , generate line for one record 
          *
          * @param array $res a single result in the form of an array
          * @param boolean $object  whether data was derived from a contact object  
          *
          * @return string $str , this is single record coverted to heshin format 
          */  
        
        function generateHeshinString($res,$object=false){
                            $log = $this->log;
                              $str = "";
                                if(!$this->checkHeshinArray($res,$object)){
                                    return false;
                                }
                                
                                
                                $str .= str_pad(" ",8," ",STR_PAD_LEFT); //Blank spaace in Heshin.prm
				$str .= str_pad($res['id'],15," ",STR_PAD_LEFT);//Customer key  9-24 
				$str .= str_pad(" ",3," ",STR_PAD_LEFT); // 3 blank spaces 
                                
                                if(!empty($res['name']))
                                {
                                    $temp = iconv('UTF-8','Windows-1255',$res['name']);
                                    if(preg_match("/^\p{Hebrew}+$/u", $temp))
                                        $temp = strrev($temp);
                                    //Fix the name so it should work windows-1255
                                    
                                    $str .= str_pad(substr($temp,0,50),50," ",STR_PAD_LEFT);
                                    // 27 to 77 name for customer 
                                    
                                }
                                else
                                {
                                    $str .= str_pad(" ",50," ",STR_PAD_LEFT);
                                    if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : Name is empty for record number ".$res['id']);
                                }
                                
				$str .= str_pad(" ",1," ",STR_PAD_LEFT);
				$str .= str_pad(" ",9," ",STR_PAD_LEFT); //agent nuber that -for now is empty
				$str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                
				if(!empty($res['phone']))
                                    $str .= str_pad($res['phone'],30," ",STR_PAD_LEFT); //Phone numbers 88 - 118
				else
                                {
                                    $str .= str_pad(" ",30," ",STR_PAD_LEFT); // if phone number is empty fill it with blanks
                                    if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : Phone is empty for record number ".$res['id']);
                                }
                                
				$str .= str_pad(" ",1," ",STR_PAD_LEFT); //blank space between 118 and 119 
                                
				if(!empty($res['address'])) //address  119 - 169 
                                {
                                    $temp = iconv('UTF-8','Windows-1255',$res['address']);
                                    if(preg_match("/^\p{Hebrew}+$/u", $temp))
                                        $temp = strrev($temp);
                                    // address conversion from utf-8 to windows-1255 supported by hash
                                        
                                    $str .= str_pad(substr($temp,0,50),50," ",STR_PAD_LEFT);
                                }
				else
                                {
                                    $str .= str_pad(" ",50," ",STR_PAD_LEFT);
                                    //if address does not exist , put 50 blank places
                                    
                                    if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : address is empty for record number ".$res['id']);
                                }
                                
				$str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                // 1 blank space 
				if(!empty($res['city_id']))
                                    $str .= str_pad($res['city_id'],20," ",STR_PAD_LEFT); // City information 
				else
                                {
                                    $str .= str_pad(" ",20," ",STR_PAD_LEFT);
                                    if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : city_id is empty for record number ".$res['id']);
                                }
				$str .= str_pad(" ",1," ",STR_PAD_LEFT);
				$str .= str_pad(" ",4," ",STR_PAD_LEFT); // discount  2 number before point 2 nnumber after point -for now is empty
				$str .= str_pad(" ",1," ",STR_PAD_LEFT);
                                
                                
                                // Put percentage_withholding , else put in 4 blank spaces
				if( array_key_exists("percentage_withholding", $res) && !empty($res['percentage_withholding'])) 
                                    $str .=  str_pad(str_replace('.','',sprintf("%1.2f",abs($res['percentage_withholding']))),4," ",STR_PAD_LEFT); 
				else
                                {
                                    $str .= str_pad(" ",4," ",STR_PAD_LEFT);
                                    if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : business_number is empty for record number ".$res['id']);
                                }
                                // Put business_number , else put in 7 blank spaces
                                if(!empty($res['business_number']))
                                    $str .= str_pad(substr($res['business_number'],0,7),7," ",STR_PAD_LEFT);
				else
                                {
                                    $str .= str_pad(" ",7," ",STR_PAD_LEFT);
                                    if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : business_number is empty for record number ".$res['id']);
                                }
                                
				$str .= str_pad(" ",1," ",STR_PAD_LEFT);

                                // Put email , else put in 50 blank spaces
				if(!empty($res['email']))
                                    $str .= str_pad(substr(iconv('UTF-8','Windows-1255',$res['email']),0,50),50," ",STR_PAD_LEFT);                             
				else
                                {
                                    $str .= str_pad(" ",50," ",STR_PAD_LEFT);
                                    if(is_object($log)) $log->warn(date('Y-m-d H:i:s')." : Email is empty for record number ".$res['id']);
                                }
                                // newline

				$str .= "\r\n";
                            
                                return $str;
             }
             
             
        
          }
          