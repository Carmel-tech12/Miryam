<?php 
 error_reporting(E_ALL);
/**********includes payproces *************/
 include('app/payprocess.php');
 
include('app/heshinprocess.php');
include('app/moveininvoice.php');
include('app/moveinreceipt.php');

/*
 * 
 * imoveinforinvoice Test
 * 
 * 
 * 
 */
$downloadFile = false;
if(isset($_GET["trigger"]) && is_numeric($_GET["trigger"]) && $_GET["trigger"] ==1){
    $downloadFile = true;
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="heshin.doc"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    
}


 $object = new Moveininvoice();
 
  $object->CardTransactions = 88888888;
 $object->VATTicketDeals = 88888888;
 $object->CashFundCard = 88888888;
 $object->CardCreditFund = 88888888;
 
 
$str = $object->moveininvoicewithDateandtime("2016-09-25 03:10:00", "2016-12-20 03:10:00", null,null,true);

/*
 * 
 *  Instead of using the filters provided , you can request your own data array by using functions 
 *  generatemoveinWithString , which requires two parameters a multidimentional array and whether to return a file pointer 
 * 
 * 
 */


if (is_resource($str)) {
    
    $stat = fstat($str);
    $size = $stat['size'];

    header('Content-Length: ' . $size);
        rewind($str);
     echo    stream_get_contents($str);
}


if(!$downloadFile)
echo $object->error;
 
?>
