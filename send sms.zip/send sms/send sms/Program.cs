﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace send_sms
{
    class Program
    {
        static void Main(string[] args)
        {

            // Set our Account SID and Auth Token
            const string accountSid = "AC666784d6d4d500fa141ba313499a8aa0";
            const string authToken = "9d5c3b8ae2c8429860cc21f5aab5abb3";

            // Initialize the Twilio client
            TwilioClient.Init(accountSid, authToken);

            // make an associative array of people we know, indexed by phone number
           // var people = new Dictionary<string, string>() {
           //     {"+14158675309", "Curious George"},
           //     {"+14158675310", "Boots"},
           //     {"+14158675311", "Virgil"}
           // };

            // Iterate over all our friends
          //  foreach (var person in people)
           // {
                // Send a new outgoing SMS by POSTing to the Messages resource
                MessageResource.Create(from: new PhoneNumber("+18174846767"), // From number, must be an SMS-enabled Twilio number
                    to: new PhoneNumber("0523600474"), body:"Hey Liat its from miryam!");

              //  Console.WriteLine($"Sent message to {person.Value}");
         //   }
        }
    }
}

        