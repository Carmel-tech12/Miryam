﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Twilio.Mvc")]
[assembly: AssemblyDescription("ASP.NET MVC Helpers for Twilio")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("cdecab7a-0a8f-4dfe-898c-1647f63132b2")]