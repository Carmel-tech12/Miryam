﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Twilio.Client.Capability")]
[assembly: AssemblyDescription("Twilio Client capability token generator for use with Twilio.js.")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("e9e02cd4-b3fe-4e35-9aef-43936331f485")]