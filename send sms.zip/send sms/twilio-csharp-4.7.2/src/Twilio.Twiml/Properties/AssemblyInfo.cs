﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Twilio.TwiML")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("a17cd566-d258-4df9-a873-0193c137b842")]