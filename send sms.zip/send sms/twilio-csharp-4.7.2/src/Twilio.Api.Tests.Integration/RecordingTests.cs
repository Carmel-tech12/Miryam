﻿using System;
using NUnit.Framework;

namespace Twilio.Api.Tests.Integration
{
    [TestFixture]
    public class RecordingTests
    {
        [Test]
        public void TestMethod1()
        {
        }
    }
}
