﻿using System;
using NUnit.Framework;

namespace Twilio.Api.Tests.Integration
{
    [TestFixture]
    public class ConnectAppTests
    {
        //get/list/update

        [Test]
        public void TestMethod1()
        {
        }
    }
}
