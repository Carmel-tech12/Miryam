﻿using System;
using NUnit.Framework;

namespace Twilio.Api.Tests.Integration
{
    [TestFixture]
    public class TranscriptionTests
    {
        [Test]
        public void TestMethod1()
        {
        }
    }
}
