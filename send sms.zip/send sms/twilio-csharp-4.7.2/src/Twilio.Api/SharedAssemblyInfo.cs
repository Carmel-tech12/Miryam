﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Twilio")]
[assembly: AssemblyProduct("Twilio")]
[assembly: AssemblyCopyright("Copyright Twilio")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("3.4.1.0")]
[assembly: AssemblyFileVersion("3.4.1.0")]
