﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Twilio
{
    public class Capabilities
    {
        public bool Voice { get; set; }
        public bool SMS { get; set; }
        public bool MMS { get; set; }
    }
}
