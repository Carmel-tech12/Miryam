using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Twilio
{
    public class IceServer
    {
        public string Url { get; set; }
        public string Username { get; set; }
        public string Credential { get; set; }
    }
}
