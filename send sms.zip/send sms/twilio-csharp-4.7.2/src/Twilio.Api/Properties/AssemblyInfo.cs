﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Twilio.Api")]
[assembly: AssemblyDescription("API wrapper for the Twilio REST API")]
[assembly: AssemblyConfiguration("")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("c2354ee7-e275-4969-9cdb-21cfcdd4c0b0")]