﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace ifunction.Twilio
{
    /// <summary>
    /// Enum for Messaging State
    /// </summary>
    [DataContract]
    public enum MessagingStatus
    {
        /// <summary>
        /// Value indicating it is Unknown
        /// </summary>
        [EnumMember]
        Unknown = 0,
        /// <summary>
        /// Value indicating it is Delivered
        /// </summary>
        [EnumMember]
        Delivered,
        /// <summary>
        /// Value indicating it is Failed
        /// </summary>
        [EnumMember]
        Failed,
        /// <summary>
        /// Value indicating it is Queued
        /// </summary>
        [EnumMember]
        Queued
    }
}
