﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Net.Http;
using HttpBrowsing;

namespace testConnection
{
    class Program
    {
        public static OleDbConnection con;
        static void Main(string[] args)
        {
            
            //con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source = C:\\Installations\\sales.mdb;Jet OLEDB:Database Password = SaSel;");
            con = new OleDbConnection("Provider = Microsoft.Jet.OLEDB.4.0; Data Source = C:\\Users\\Administrator\\OneDrive\\mdb\\sales.mdb;Jet OLEDB:Database Password = SaSel;");
            //prcoessIMoveINNFile("C:\\miryam\\imovein.doc");

            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load("CarmelDira2ToHash.xml");
                string user_name, pass, login_url, moveinURL, kupaInURL, hashImoveInInputPath, hashKupaInInputPath;
                #region configData
                user_name = xmlDoc.SelectSingleNode("//user_name").InnerText;
                pass = xmlDoc.SelectSingleNode("//pass").InnerText;
                login_url = xmlDoc.SelectSingleNode("//login_url").InnerText;
                moveinURL = xmlDoc.SelectSingleNode("//moveinURL").InnerText;
                kupaInURL = xmlDoc.SelectSingleNode("//kupaInURL").InnerText;
                hashImoveInInputPath = xmlDoc.SelectSingleNode("//hashImoveInInputFolder").InnerText;
                hashKupaInInputPath = xmlDoc.SelectSingleNode("//hashKupaInInputFolder").InnerText;
                #endregion
                string hashDestinationIMoveinFolder = Path.GetDirectoryName(hashImoveInInputPath);
                string hashDestinationIKupainFolder = Path.GetDirectoryName(hashKupaInInputPath);
                SimulateHttp sh = new HttpBrowsing.SimulateHttp();

                //EventLog.WriteEntry("CarmelToHashService", "In Main Before Login...", EventLogEntryType.Information);

                sh.doLogin(user_name, pass, login_url);//http:/ganli.dira2.co.il/base/rest_login -add another '/' to url after http

                //EventLog.WriteEntry("CarmelToHashService", "trying to download imovein.doc", EventLogEntryType.FailureAudit);


                sh.downloadFile(moveinURL, hashImoveInInputPath);//http:/ganli.dira2.co.il/hashmapping/systems/imovein -add another '/' to url after http
                prcoessIMoveINNFile(hashImoveInInputPath);

               // EventLog.WriteEntry("CarmelToHashService", "In Main Before Download kupaIn File...", EventLogEntryType.Information);


                // sh.downloadFile(kupaInURL, hashKupaInInputPath);//http:/ganli.dira2.co.il/hashmapping/systems/kupain -add another '/' to url after http
                // prcoessKupaINFile(hashImoveInInputPath);


                //EventLog.WriteEntry("CarmelToHashService", "Finished...", EventLogEntryType.Information);
                //sh.doLogout("http:/ganli.dira2.co.il");

            }
            catch (Exception e)
            {
                EventLog.WriteEntry("CarmelToHashService", "Error from Schedule Task:" + e.ToString(), EventLogEntryType.Error);
            }
        }
        private static void prcoessIMoveINNFile(string fileLocation)
        {
           // File.AppendAllText("c:\\miryam\\debuglin.txt", "start function" + Environment.NewLine);
            var lines = File.ReadAllLines(fileLocation);
            string orderNumber = lines[0].Substring(9, 7).Trim(),
                Tagent = lines[0].Substring(69, 3).Trim(),
                Tcustomer = lines[0].Substring(16, 17).Trim(),
                Tstatus, TIsPrint;
            string Tsemel, Sokhen, lakoh, status = "0", Prnt = "1";
            float TtotalPrice = 0, TpercentTax = 17, TtotalTax = 0, Skhom, maam, skhomNOMaam, AhuzMaam, kamot, mehir;
            string shem, rekhev, Tcar = lines[0].Substring(60, 2).Trim(), dateOrder, parit, phanaha, discount = "0", hanaha;
            string tarikh = "20" + lines[0].Substring(50, 2).Trim() + "-" + lines[0].Substring(48, 2).Trim() + "-" + lines[0].Substring(46, 2).Trim();
            //File.AppendAllText("c:\\miryam\\debuglin.txt", "before foreach" + Environment.NewLine);
            foreach (var line in lines)
            {
                //File.AppendAllText("c:\\miryam\\debuglin.txt", " if new orderNumber" + orderNumber + " the current order " + line.Substring(9, 7).Trim() + Environment.NewLine);
                //it new order
                if (orderNumber != line.Substring(9, 7).Trim())
                {
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "in new order" + Environment.NewLine);
                    //THazmana 
                    Tsemel = orderNumber;
                    Sokhen = Tagent;
                    dateOrder = tarikh;
                    lakoh = Tcustomer;
                    rekhev = Tcar;
                    if (rekhev == "")
                        rekhev = "1";
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "rekhev" + Environment.NewLine);
                    Skhom = TtotalPrice;
                    Tstatus = status;
                    maam = 121;//TtotalPrice*17%;
                    hanaha = discount;
                    skhomNOMaam = TtotalPrice - TtotalTax;
                    AhuzMaam = TpercentTax;
                    TIsPrint = Prnt;
                    // string strDate = "01-02-17";
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "before date = " + dateOrder + Environment.NewLine);
                    DateTime datDate = DateTime.Parse(dateOrder);
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "before insert order" + Environment.NewLine);
                    //insert data to Thazmana
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "insert into THazmana (semel,sokhen,tarikh,lakoh,rekhev,skhom,status,Hishbonit,Measher,mekabel,maam,hanaha,Yetra,New,skhomNOMaam,shem,AhuzMaam) " +
                                       "values(@semel,@sokhen,@tarikh,@lakoh,@rekhev,@skhom,@status,@Hishbonit,@Measher,@mekabel,@maam,@hanaha,@Yetra,@New,@skhomNOMaam,@shem,@AhuzMaam);";

                    cmd.Parameters.AddWithValue("@semel", Int32.Parse(Tsemel));
                    cmd.Parameters.AddWithValue("@sokhen", Int32.Parse(Sokhen));
                    cmd.Parameters.Add("@tarikh", OleDbType.Date);
                    cmd.Parameters[2].Value = datDate;
                    cmd.Parameters.AddWithValue("@lakoh", Int32.Parse(lakoh));
                    cmd.Parameters.AddWithValue("@rekhev", Int32.Parse(rekhev));
                    cmd.Parameters.AddWithValue("@skhom", Skhom);
                    cmd.Parameters.AddWithValue("@status", Int32.Parse(Tstatus));
                    cmd.Parameters.AddWithValue("@Hishbonit", 0);
                    cmd.Parameters.AddWithValue("@Measher", 0);
                    cmd.Parameters.AddWithValue("@mekabel", " ");
                    cmd.Parameters.AddWithValue("@maam", maam);
                    cmd.Parameters.AddWithValue("@hanaha", float.Parse(hanaha));
                    cmd.Parameters.AddWithValue("@Yetra", 0);
                    cmd.Parameters.AddWithValue("@New", 1);
                    cmd.Parameters.AddWithValue("@skhomNOMaam", skhomNOMaam);
                    cmd.Parameters.AddWithValue("@shem", " ");
                    cmd.Parameters.AddWithValue("@AhuzMaam", TpercentTax);

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch { }
                    finally
                    {
                        con.Close();
                    }
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "after insert order" + Environment.NewLine);
                    TtotalPrice = 0;
                    TtotalTax = 0;
                    orderNumber = line.Substring(9, 7).Trim();
                    Tagent = line.Substring(69, 3).Trim();
                    Tcustomer = line.Substring(16, 17).Trim();
                    Tcar = line.Substring(60, 2).Trim();
                    tarikh = "20" + lines[0].Substring(50, 2).Trim() + "-" + lines[0].Substring(48, 2).Trim() + "-" + lines[0].Substring(46, 2).Trim();
                }
                try
                {
                    //PHazmana 
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "start new orderline" + Environment.NewLine);
                    parit = line.Substring(117, 11).Trim();
                    string temp = line.Substring(130, 10).Trim();
                    if (temp != "")
                        kamot = float.Parse(line.Substring(130, 10).Trim()) / 100;
                    else
                        kamot = 0;
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "kamot" + Environment.NewLine);
                    temp = line.Substring(140, 10).Trim();
                    if (temp != "")
                        mehir = float.Parse(line.Substring(140, 10).Trim()) / 100;
                    else
                        mehir = 0;
                   // File.AppendAllText("c:\\miryam\\debuglin.txt", "mehir" + Environment.NewLine);
                    TtotalPrice += mehir;
                    temp = line.Substring(151, 5).Trim();
                    if (temp != "")
                        phanaha = (float.Parse(temp) / 100).ToString();
                    else
                        phanaha = "0";
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "sphanaha" + Environment.NewLine);
                    discount = phanaha;
                    shem = line.Substring(156, 17).Trim();
                    //TtotalTax +=float.Parse(mehir*17%);
                   // File.AppendAllText("c:\\miryam\\debuglin.txt", "before insert orderline" + Environment.NewLine);
                    //insert to database
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "insert into Phazmana (semel,parit,kamot,mehir,Hanaha,shem,Lngth,Wdth,mustmaam,KamotLineMin) values(" + orderNumber + "," + parit + "," + kamot.ToString() + "," + mehir.ToString() + "," + phanaha + ",'" + shem + "', 1 ,1 ,1, 0 );";
                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch { }
                    finally
                    {
                        con.Close();
                    }
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "after insert orderline" + Environment.NewLine);
                }
                catch
                {
                }
                //if it last line
                if (line == lines[lines.Length -1])
                {
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "in last order" + Environment.NewLine);
                    //THazmana 
                    Tsemel = orderNumber;
                    Sokhen = Tagent;
                    dateOrder = tarikh;
                    lakoh = Tcustomer;
                    rekhev = Tcar;
                    if (rekhev == "")
                        rekhev = "1";
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "last rekhev" + Environment.NewLine);
                    Skhom = TtotalPrice;
                    Tstatus = status;
                    maam = 121;//TtotalPrice*17%;
                    hanaha = discount;
                    skhomNOMaam = TtotalPrice - TtotalTax;
                    AhuzMaam = TpercentTax;
                    TIsPrint = Prnt;
                    // string strDate = "01-02-17";
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "last before date = " + dateOrder + Environment.NewLine);
                    DateTime datDate = DateTime.Parse(dateOrder);
                    //File.AppendAllText("c:\\miryam\\debuglin.txt", "last before insert order" + Environment.NewLine);
                    //insert data to Thazmana
                    OleDbCommand cmd = new OleDbCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "insert into THazmana (semel,sokhen,tarikh,lakoh,rekhev,skhom,status,Hishbonit,Measher,mekabel,maam,hanaha,Yetra,New,skhomNOMaam,shem,AhuzMaam) " +
                                       "values(@semel,@sokhen,@tarikh,@lakoh,@rekhev,@skhom,@status,@Hishbonit,@Measher,@mekabel,@maam,@hanaha,@Yetra,@New,@skhomNOMaam,@shem,@AhuzMaam);";

                    cmd.Parameters.AddWithValue("@semel", Int32.Parse(Tsemel));
                    cmd.Parameters.AddWithValue("@sokhen", Int32.Parse(Sokhen));
                    cmd.Parameters.Add("@tarikh", OleDbType.Date);
                    cmd.Parameters[2].Value = datDate;
                    cmd.Parameters.AddWithValue("@lakoh", Int32.Parse(lakoh));
                    cmd.Parameters.AddWithValue("@rekhev", Int32.Parse(rekhev));
                    cmd.Parameters.AddWithValue("@skhom", Skhom);
                    cmd.Parameters.AddWithValue("@status", Int32.Parse(Tstatus));
                    cmd.Parameters.AddWithValue("@Hishbonit", 0);
                    cmd.Parameters.AddWithValue("@Measher", 0);
                    cmd.Parameters.AddWithValue("@mekabel", " ");
                    cmd.Parameters.AddWithValue("@maam", maam);
                    cmd.Parameters.AddWithValue("@hanaha", float.Parse(hanaha));
                    cmd.Parameters.AddWithValue("@Yetra", 0);
                    cmd.Parameters.AddWithValue("@New", 1);
                    cmd.Parameters.AddWithValue("@skhomNOMaam", skhomNOMaam);
                    cmd.Parameters.AddWithValue("@shem", " ");
                    cmd.Parameters.AddWithValue("@AhuzMaam", TpercentTax);

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch { }
                    finally
                    {
                        con.Close();
                    }
                   // File.AppendAllText("c:\\miryam\\debuglin.txt", "last after insert order" + Environment.NewLine);
                
                }

            }
        }
    }
}
